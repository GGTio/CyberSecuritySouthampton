void copyData(char *userId) {  
    char  smallBuffer[10];  
    strcpy(smallBuffer, userId);
 }  
 int main(int argc, char *argv[]) {  
 char *userId = "01234567890"; 
 copyData (userId); 
 }

